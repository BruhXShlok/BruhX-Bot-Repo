#
# TCG SELFBOT :)

```Key Features:```
- 1-Day Prune
- Screenshot Command
- Control SB With Another Account.
- And stuff we're to lazy to write

# How To Use It : 

```
Open Config :
- Fill in config.json
- Ignore requirements.txt it's useless fr
- Run main.py obv
```

# Developers :

- `Ƭᴄɢ᭄͢ Styx⚘ˣʳ#1234`

# Troubleshooting :

> Join https://discord.gg/tcgop and ping Owner or styx from the dev team.
