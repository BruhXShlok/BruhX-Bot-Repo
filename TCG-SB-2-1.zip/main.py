pip import os
os.system("pip install -r requirements.txt")
os.system("pip install colorama")
os.system("pip install jishaku ")
import discord
from discord.ext import commands
import json 
import httpx
import random
import pypresence 
import requests
import datetime
from colorama import Fore
import asyncio 
import sys
import threading
import json
import aiohttp
from aiohttp import request
import time
import sys
from pypresence import Presence
import io
import contextlib
import textwrap
with open("./config/config.json","r") as conf:
    data = json.load(conf)
    
    TcgEncrypt = data["Token"]
    TcgEncrypt1 = data["Prefix"]
    TcgEncrypt2 = data["AllowedUsers"]
    TcgEncrypt3 = data["Password"]
    TcgEncrypt4 = data["ChannelNames"]
    TcgEncrypt5 = data["RoleNames"]
    TcgEncrypt6 = data["ServerNames"]
    TcgEncrypt7 = data["WebhookSpamMessages"]
    
def check_token():
    if requests.get("https://discord.com/api/v9/users/@me",headers={"Authorization":TcgEncrypt}).status_code == 200:
        return "user"
    else:
        return "bot"
    
token_type = check_token()
intents = discord.Intents.all()
if token_type == "user":
    headers = {"Authorization":TcgEncrypt}
    client = commands.Bot(command_prefix=TcgEncrypt1, help_command=None, self_bot=True,intents=intents)
else:
    headers = {"Authorization":f"Bot {TcgEncrypt}"}
    client = commands.Bot(command_prefix=TcgEncrypt1, intents=intents, help_command=None)
@client.listen()
async def on_ready():
    print(f"""
    
   ▄████████    ▄███████▄ ▄██   ▄           ▄████████    ▄████████  ▄█          ▄████████ ▀█████████▄   ▄██████▄      ███     
  ███    ███   ███    ███ ███   ██▄        ███    ███   ███    ███ ███         ███    ███   ███    ███ ███    ███ ▀█████████▄ 
  ███    █▀    ███    ███ ███▄▄▄███        ███    █▀    ███    █▀  ███         ███    █▀    ███    ███ ███    ███    ▀███▀▀██ 
  ███          ███    ███ ▀▀▀▀▀▀███        ███         ▄███▄▄▄     ███        ▄███▄▄▄      ▄███▄▄▄██▀  ███    ███     ███   ▀ 
▀███████████ ▀█████████▀  ▄██   ███      ▀███████████ ▀▀███▀▀▀     ███       ▀▀███▀▀▀     ▀▀███▀▀▀██▄  ███    ███     ███     
         ███   ███        ███   ███               ███   ███    █▄  ███         ███          ███    ██▄ ███    ███     ███     
   ▄█    ███   ███        ███   ███         ▄█    ███   ███    ███ ███▌    ▄   ███          ███    ███ ███    ███     ███     
 ▄████████▀   ▄████▀       ▀█████▀        ▄████████▀    ██████████ █████▄▄██   ███        ▄█████████▀   ▀██████▀     ▄████▀   
                                                                   ▀                                                          

            - https://github.com/
            
    ・Logged in as {client.user}
    ・Type {TcgEncrypt1}help to get list of all the commands.
    ・Created by Team BX™
    ・https://discord.gg/bxop""")    


for file in os.listdir("./cogs"):
	if file.endswith(".py"):
		client.load_extension(f"cogs.{file[:-3]}")
client.load_extension("jishaku")
if token_type == "user":
    client.run(TcgEncrypt, bot=False)
else:
    client.run(TcgEncrypt)
