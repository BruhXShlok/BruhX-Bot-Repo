from discord.ext import commands, tasks
import discord
import main

class HelpCog(commands.Cog):
	def __init__(self, client):
		self.client = client
		
	@commands.Cog.listener('on_message')	
	async def helpcommands(self, message):
		if message.author.id in main.TcgEncrypt2:
			async for messages in message.channel.history(limit=3):				
				if messages.id == message.id:
					try:
						arg = messages.content.lower().split()[1]
					except:
						arg = False
					if messages.content.lower().split()[0] == (f"{main.TcgEncrypt1}help") and not arg:
						await message.reply(f"""**Tcg Self Bot | Total Commands: 52**
						
> ・`{main.TcgEncrypt1}help` - Shows this page
> ・`{main.TcgEncrypt1}help nuke` - Shows nuking commands.
> ・`{main.TcgEncrypt1}help text` - Shows text commands.
> ・`{main.TcgEncrypt1}help utility` - Shows utility commands.
> ・`{main.TcgEncrypt1}help fun` - Shows fun commands.
> ・`{main.TcgEncrypt1}help status` - Shows status commands.
> ・`{main.TcgEncrypt1}help hack` - Shows hack commands.
""")
					elif messages.content.lower().split()[0] == (f"{main.TcgEncrypt1}help") and messages.content.lower().split()[1] == (f"hack"):
							await message.reply(f"""**Tcg Self Bot V6 | Hack Commands (3)**
						
・`{main.TcgEncrypt1}tokendox <token>` - Get info on a token.
・`{main.TcgEncrypt1}delhook <url>` - Deletes a webhook.
・`{main.TcgEncrypt1}doxip <ip>` - Get info on an ip.""")
					elif messages.content.lower().split()[0] == (f"{main.TcgEncrypt1}help") and messages.content.lower().split()[1] == (f"fun"):
							await message.reply(f"""**Tcg Self Bot | Fun Commands (4)**
						
・`{main.TcgEncrypt1}dickometer <@user>` - returns dick size
・`{main.TcgEncrypt1}avsteal <@user>` - Steals avatar of the user. 
・`{main.TcgEncrypt1}joke` - Shows A Random Joke.
・`{main.TcgEncrypt1}reddit` - Random Reddit Meme.
""")
					elif messages.content.lower().split()[0] == (f"{main.TcgEncrypt1}help") and messages.content.lower().split()[1] == (f"utility"):
						await message.reply(f"""**Tch Self Bot | Utility Commands (9)**
						
> ・`{main.TcgEncrypt1}avatar <@user>` - Get avatar of any user. 
> ・`{main.TcgEncrypt1}banner <@user>` - Get banner of any user.
> ・`{main.TcgEncrypt1}serverinfo <server id>` - Get info about any server.
> ・`{main.TcgEncrypt1}userinfo <@user>` - Get info about any user.
> ・`{main.TcgEncrypt1}pingweb <url>` - Pings a website and returns it's status code.'
> ・`{main.TcgEncrypt1}idtoname <id>` - Get username of any user by their id.
> ・`{main.TcgEncrypt1}screenshot <website>` - Sends screenshot of the website.
> ・`{main.TcgEncrypt1}join <vc id>` - Joins the vc.
> ・`{main.TcgEncrypt1}leave` - Leaves the vc.
""")	

					elif messages.content.lower().split()[0] == (f"{main.TcgEncrypt1}help") and messages.content.lower().split()[1] == "text":
						await message.reply(f"""**Tcg Self Bot | Text Commands(8)**
						
>・`{main.TcgEncrypt1}spam <amount> <message>` - Haha spam go brrrr.
>・`{main.TcgEncrypt1}spamping` - Spam pings random users in the server.
>・`{main.TcgEncrypt1}spamthread <amount>` - Spam creates threads.
>・`{main.TcgEncrypt1}spampin <amount>` - Spam pins messages.
>・`{main.TcgEncrypt1}sendhook <url> <message>` - ok 
>・`{main.TcgEncrypt1}embedhook <url> <title> <image> <description>` - ok 
>・`{main.TcgEncrypt1}ghostmsg <message>` - Deletes the command immediatly, useful for ghost pings.
>・`{main.TcgEncrypt1}snipe` - ok 
""")			

					elif messages.content.lower().split()[0] == (f"{main.TcgEncrypt1}help") and messages.content.lower().split()[1] == "nuke":
						await message.reply(f"""**Tcg Self Bot | Nuke Commands(13)**
				
> ・`{main.TcgEncrypt1}channelfuckery` - You know it.
> ・`{main.TcgEncrypt1}botmassban <prefix> <cooldown>` - Initiates Massban In A Server using a bot.
> ・`{main.TcgEncrypt1}massban` - Initiates Massban In A Server.
> ・`{main.TcgEncrypt1}masskick` - Initiates Masskick In A Server.
> ・`{main.TcgEncrypt1}rolespam` - Spams Roles In A Server.
> ・`{main.TcgEncrypt1}channelspam` - Spams Channels In A Server.
> ・`{main.TcgEncrypt1}delroles` - Deletes roles.
> ・`{main.TcgEncrypt1}delchannels` - Deletes channels.
> ・`{main.TcgEncrypt1}renamechannels` - Renames channels.
> ・`{main.TcgEncrypt1}renameroles` - Renames roles.
> ・`{main.TcgEncrypt1}prune <rm> <days>` - Prunes the server. RM stands for role members i.e. if rm is 20 it will ignore those roles who have less than or equal to 20 members.
> ・`{main.TcgEncrypt1}checkprune <days>` - Returns the estimated amount of members pruned .
""")			
					elif messages.content.lower().split()[0] == (f"{main.TcgEncrypt1}help") and messages.content.lower().split()[1] == (f"status"):
						await message.reply(f"""**Tcg Self Bot | Status Commands (5)**

> ・`{main.TcgEncrypt1}play <name>` - Playing Status.
> ・`{main.TcgEncrypt1}stream <name>` - Streaming Status.
> ・`{main.TcgEncrypt1}watching <name>` - Watching Status.
> ・`{main.TcgEncrypt1}listening <name>` - Listenting Status.
> ・`{main.TcgEncrypt1}stopactivity <name>` - Stops Activity.
""")			

					elif messages.content.lower().split()[0] == (f"{main.TcgEncrypt1}help") and messages.content.lower().split()[1] == (f"nsfw"):
						await message.reply(f"""**Tcg Self Bot | Nsfw Commands(10)**
						
> ・`{main.TcgEncrypt1}nsfw 4k` - 4k Porn.
> ・`{main.TcgEncrypt1}nsfw ass` - Real Ass.
> ・`{main.TcgEncrypt1}nsfw boobs` - Real Boobs.
> ・`{main.TcgEncrypt1}nsfw cum` - Cum Porn.
> ・`{main.TcgEncrypt1}nsfw feet` - Feet Pics.
> ・`{main.TcgEncrypt1}nsfw hentai` - Random Hentai.
> ・`{main.TcgEncrypt1}nsfw spank` - Spank!.
> ・`{main.TcgEncrypt1}nsfw pussy` - Pussy Porn.
> ・`{main.TcgEncrypt1}nsfw lesbian` - Lesban Porn.
> ・`{main.TcgEncrypt1}nsfw lewd` - Random Porn.
""")	
						
def setup(client):
	client.add_cog(HelpCog(client))
